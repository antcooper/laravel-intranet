# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.10)
# Database: intranet
# Generation Time: 2016-05-09 09:02:05 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table tbl_domains
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_domains`;

CREATE TABLE `tbl_domains` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `charge` decimal(5,2) NOT NULL DEFAULT '0.00',
  `renewal_date` timestamp NOT NULL,
  `duration` tinyint(3) unsigned NOT NULL DEFAULT '12',
  `send_notification` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `company` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host_id` int(10) unsigned DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `domains_host_id_foreign` (`host_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `tbl_domains` WRITE;
/*!40000 ALTER TABLE `tbl_domains` DISABLE KEYS */;

INSERT INTO `tbl_domains` (`id`, `domain`, `charge`, `renewal_date`, `duration`, `send_notification`, `email`, `first_name`, `last_name`, `company`, `host_id`, `notes`, `created_at`, `updated_at`)
VALUES
	(1,'shinetraining.co.uk',50.00,'2017-02-01 00:00:00',12,1,'Micheladeegan@aol.com','Michela','Deegan','Shine Training Ltd',3,'','2016-01-14 17:29:24','2016-01-19 17:53:49'),
	(2,'this.com',100.00,'2016-01-19 00:00:00',12,1,'fred@example.com','Ant','Cooper','',1,'','2016-01-19 16:39:05','2016-01-19 16:39:05'),
	(4,'motor-sports.tv',100.00,'2016-12-12 00:00:00',12,1,'ant@outsrc.co.uk','Mr','Hat','',2,'','2016-01-19 16:58:46','2016-01-19 16:58:46'),
	(6,'asdfasd',0.00,'2015-12-23 00:00:00',12,1,'ant@outsrc.co.uk','asdf','asd','',NULL,'','2016-01-19 17:01:12','2016-01-19 17:01:12'),
	(7,'nohost.com',12.00,'2015-12-13 00:00:00',12,0,'anthony.cooper@me.com','Mr','Hat','',1,'','2016-01-19 17:07:42','2016-01-19 17:51:53'),
	(8,'asd',100.00,'2015-12-01 00:00:00',12,1,'anthony.cooper@me.com','Ant','Cooper','',0,'','2016-01-19 17:09:07','2016-01-19 17:09:07'),
	(9,'mydomain.com',100.00,'2016-12-20 00:00:00',12,1,'ant@outsrc.co.uk','Ant','Cooper','ad',0,'','2016-01-19 17:12:31','2016-01-19 17:12:31');

/*!40000 ALTER TABLE `tbl_domains` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_hosts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_hosts`;

CREATE TABLE `tbl_hosts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `tbl_hosts` WRITE;
/*!40000 ALTER TABLE `tbl_hosts` DISABLE KEYS */;

INSERT INTO `tbl_hosts` (`id`, `name`, `is_active`, `created_at`, `updated_at`)
VALUES
	(1,'Arcustech',1,'2016-01-14 17:27:21','2016-01-14 17:27:21'),
	(2,'Digital Ocean',1,'2016-01-14 17:27:26','2016-01-14 17:27:26'),
	(3,'Rackspace Cloudsites',1,'2016-01-14 17:27:32','2016-01-14 17:27:32'),
	(4,'Melbourne',1,'2016-01-14 17:27:37','2016-01-14 17:27:37'),
	(5,'WebFaction',1,'2016-01-14 17:27:48','2016-01-14 17:27:48'),
	(6,'Apple',1,'2016-01-19 17:33:52','2016-01-19 17:33:52');

/*!40000 ALTER TABLE `tbl_hosts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_migrations`;

CREATE TABLE `tbl_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `tbl_migrations` WRITE;
/*!40000 ALTER TABLE `tbl_migrations` DISABLE KEYS */;

INSERT INTO `tbl_migrations` (`migration`, `batch`)
VALUES
	('2014_10_12_000000_create_users_table',1),
	('2014_10_12_100000_create_password_resets_table',1),
	('2016_01_12_152639_create_hosts_table',1),
	('2016_01_13_122821_create_domains_table',1),
	('2016_01_15_112000_add_telephone_to_users_table',2);

/*!40000 ALTER TABLE `tbl_migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table tbl_password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_password_resets`;

CREATE TABLE `tbl_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Dump of table tbl_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `telephone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `tbl_users` WRITE;
/*!40000 ALTER TABLE `tbl_users` DISABLE KEYS */;

INSERT INTO `tbl_users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `telephone`)
VALUES
	(1,'Ant Cooper','ant@outsrc.co.uk','$2y$10$UkVxlWP2qbsjRe61q0JgAOsbrVUD.GZhnLWzdEkPbyFoYrXQoXqiu','hII2cMEjOq7BAVqQEv4KT9OwNFrwdhL6KEWFUMAj8T49qFKhQCgklhkrHMB0','2016-01-14 17:25:48','2016-01-18 21:17:56',NULL),
	(2,'Fred','anthony@outsrc.co.uk','$2y$10$9H8IEajpHQq4NQiRmJsws.3jI6x04rhqLy7i1NBRCkkMHTVzrHS6y','Q2LSwe3vTORF9b13bFizVcQLhewABrnGmR1LoXBhtd2nYdlvU8Y3MNzzcs7B','2016-01-15 11:23:26','2016-01-15 11:25:57',NULL),
	(3,'test','test@outsrc.co.uk','$2y$10$FoEg/q0HEf/g5YXHwH4IXuKkS898KQeNWLs2gxfE0FtNDAthj5kem',NULL,'2016-01-15 11:26:36','2016-01-15 11:26:36','344');

/*!40000 ALTER TABLE `tbl_users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
